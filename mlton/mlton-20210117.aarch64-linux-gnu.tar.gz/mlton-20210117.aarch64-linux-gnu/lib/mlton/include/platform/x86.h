#define MLton_Platform_Arch_host "x86"
